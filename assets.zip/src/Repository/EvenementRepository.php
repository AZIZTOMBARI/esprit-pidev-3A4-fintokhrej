<?php

namespace App\Repository;

use App\Entity\Evenement;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class EvenementRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Evenement::class);
    }

    public function findUpcoming(): array
    {
        return $this->createQueryBuilder('e')
            ->where('e.dateDebut > :now')
            ->andWhere('e.statut = :ouvert')
            ->setParameter('now', new \DateTime())
            ->setParameter('ouvert', 'OUVERT')
            ->orderBy('e.dateDebut', 'ASC')
            ->getQuery()
            ->getResult();
    }
}