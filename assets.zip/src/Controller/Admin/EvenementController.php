<?php

namespace App\Controller\Admin;

use App\Entity\Evenement;
use App\Entity\Inscription;
use App\Form\EvenementType;
use App\Repository\EvenementRepository;
use App\Repository\InscriptionRepository;
use App\Service\EvenementService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;


#[Route('/admin/evenements')]
#[IsGranted('ROLE_ADMIN')]
class EvenementController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $em,
        private EvenementService $evenementService
    ) {}

    #[Route('', name: 'app_admin_evenements', methods: ['GET'])]
    public function index(EvenementRepository $repository): Response
    {
        $evenements = $repository->findAll();

        return $this->render('admin/evenement/index.html.twig', [
            'evenements' => $evenements,
        ]);
    }

    #[Route('/{id}', name: 'app_admin_evenement_show', methods: ['GET'])]
    public function show(Evenement $evenement): Response
    {
        $stats = $this->evenementService->getStatistiquesEvenement($evenement);

        return $this->render('admin/evenement/show.html.twig', [
            'evenement' => $evenement,
            'stats' => $stats,
        ]);
    }

    #[Route('/new', name: 'app_admin_evenements_new', methods: ['GET', 'POST'])]
    public function new(Request $request): Response
    {
        $evenement = new Evenement();
        $form = $this->createForm(EvenementType::class, $evenement);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $this->em->persist($evenement);
            $this->em->flush();

            $this->addFlash('success', 'Événement créé avec succès.');
            return $this->redirectToRoute('app_admin_evenements');
        }

        return $this->render('admin/evenement/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}/edit', name: 'app_admin_evenements_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Evenement $evenement): Response
    {
        $form = $this->createForm(EvenementType::class, $evenement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->em->flush();
            $this->addFlash('success', 'Événement modifié avec succès.');
            return $this->redirectToRoute('app_admin_evenements');
        }

        return $this->render('admin/evenement/edit.html.twig', [
            'evenement' => $evenement,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}/delete', name: 'app_admin_evenements_delete', methods: ['POST'])]
    public function delete(Request $request, Evenement $evenement): Response
    {
        if ($this->isCsrfTokenValid('delete'.$evenement->getId(), $request->get('_token'))) {
            $this->em->remove($evenement);
            $this->em->flush();
            $this->addFlash('success', 'Événement supprimé avec succès.');
        }

        return $this->redirectToRoute('app_admin_evenements');
    }

    // ==================== GESTION DES INSCRIPTIONS ====================

    #[Route('/{id}/inscriptions', name: 'app_admin_inscriptions', methods: ['GET'])]
    public function gererInscriptions(Evenement $evenement, InscriptionRepository $repo): Response
    {
        $inscriptionsEnAttente = $repo->findInscriptionsEnAttente($evenement);
        $stats = $this->evenementService->getStatistiquesEvenement($evenement);

        return $this->render('admin/evenement/inscriptions.html.twig', [
            'evenement' => $evenement,
            'inscriptions_en_attente' => $inscriptionsEnAttente,
            'stats' => $stats,
        ]);
    }

    #[Route('/inscription/{id}/accepter', name: 'app_admin_inscription_accepter', methods: ['POST'])]
    public function accepterInscription(Inscription $inscription, Request $request): Response
    {
        if (!$this->isCsrfTokenValid('accepter' . $inscription->getId(), $request->get('_token'))) {
            $this->addFlash('error', 'Token CSRF invalide.');
        } else {
            try {
                $this->evenementService->accepterInscription($inscription);
                $this->addFlash('success', sprintf(
                    '✅ Inscription de %s acceptée. En attente de paiement.',
                    $inscription->getUser()->getPrenom()
                ));
            } catch (\Exception $e) {
                $this->addFlash('error', '❌ ' . $e->getMessage());
            }
        }

        $evenement = $inscription->getEvenement();
        return $this->redirectToRoute('app_admin_inscriptions', ['id' => $evenement->getId()]);
    }

    #[Route('/inscription/{id}/refuser', name: 'app_admin_inscription_refuser', methods: ['POST'])]
    public function refuserInscription(Inscription $inscription, Request $request): Response
    {
        if (!$this->isCsrfTokenValid('refuser' . $inscription->getId(), $request->get('_token'))) {
            $this->addFlash('error', 'Token CSRF invalide.');
        } else {
            try {
                $motif = $request->get('motif', 'Refuse par l\'administrateur');
                $this->evenementService->refuserInscription($inscription, $motif);
                $this->addFlash('warning', sprintf(
                    '❌ Inscription de %s refusée.',
                    $inscription->getUser()->getPrenom()
                ));
            } catch (\Exception $e) {
                $this->addFlash('error', '❌ ' . $e->getMessage());
            }
        }

        $evenement = $inscription->getEvenement();
        return $this->redirectToRoute('app_admin_inscriptions', ['id' => $evenement->getId()]);
    }

    #[Route('/inscription/{id}/remboursement', name: 'app_admin_inscription_rembourser', methods: ['POST'])]
    public function rembourserInscription(Inscription $inscription, Request $request): Response
    {
        if (!$this->isCsrfTokenValid('rembourser' . $inscription->getId(), $request->get('_token'))) {
            $this->addFlash('error', 'Token CSRF invalide.');
        } else {
            try {
                $this->evenementService->rembourserInscription($inscription);
                $this->addFlash('info', sprintf(
                    '💰 Inscription de %s remboursée.',
                    $inscription->getUser()->getPrenom()
                ));
            } catch (\Exception $e) {
                $this->addFlash('error', '❌ ' . $e->getMessage());
            }
        }

        $evenement = $inscription->getEvenement();
        return $this->redirectToRoute('app_admin_inscriptions', ['id' => $evenement->getId()]);
    }
}